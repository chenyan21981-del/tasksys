---
name: tasksys
description: Install and initialize the 18game Task Management System as a reusable OpenClaw skill.
---

# TaskSys Skill

Use this skill to deploy and initialize a complete task management system with default local IP access and admin credentials output.

## Included resources

- `assets/task_system_template/`
  - `server.js`
  - `bot.js`
  - `public/index.html`
- `scripts/install_tasksys.sh`
- `scripts/show_access_info.sh`

## Install workflow

1. Run:

```bash
bash scripts/install_tasksys.sh
```

Optional install target:

```bash
bash scripts/install_tasksys.sh /root/.openclaw/workspace/task_system
```

2. Script behavior:
- Copy API/Bot/Web template files to target directory
- Create `data.json` if missing, with **random strong admin password (PBKDF2 hash stored only)**
- Create bot env file (`~/.openclaw/task-system-bot.env`) if missing
- Install/start:
  - `task-system-bot.service` (user service) 自动安装启动
  - `task-system-api.service` 仅生成草案，**不自动 sudo 安装**（需人工审核后执行）
- API 默认绑定 `127.0.0.1`（可通过 `TASK_BIND_HOST` 覆盖）
- 若绑定到公网（如 `0.0.0.0`/`::`），`server.js` 默认拒绝启动；需显式设置 `TASK_ALLOW_PUBLIC_BIND=1` 才允许
- systemd API 草案已加入基础加固：`NoNewPrivileges`/`PrivateTmp`/`ProtectSystem=strict`/`ProtectHome=read-only`
- Auto-detect host IPs and print recommended URL
- Print admin username and one-time bootstrap password (only when initializing a new DB)

3. If bot token is not set, edit:

```bash
~/.openclaw/task-system-bot.env
```

Set `TG_TASK_BOT_TOKEN=...`, then restart:

```bash
systemctl --user restart task-system-bot.service
```

## Return access info anytime

```bash
bash scripts/show_access_info.sh
```

This prints:
- Recommended management URL (`http://<local-ip>:8090`)
- Available local IP list
- Admin username
- Password redacted by policy (not printed)

## Output format to user

After install, always return:

- 管理地址（推荐）
- 可用 IP 列表
- admin 用户名
- 若为新初始化：一次性初始密码（仅本次输出）
- 安全提示：首次登录立即修改密码；公网前先加 HTTPS/反向代理
