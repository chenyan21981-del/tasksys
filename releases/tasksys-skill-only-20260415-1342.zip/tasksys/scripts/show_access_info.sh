#!/usr/bin/env bash
set -euo pipefail
TARGET_DIR="${1:-$HOME/.openclaw/workspace/task_system}"
DB_FILE="$TARGET_DIR/data.json"

IPS=$(hostname -I 2>/dev/null | xargs)
RECOMMEND_IP=$(echo "$IPS" | awk '{for(i=1;i<=NF;i++){if($i ~ /^10\./ || $i ~ /^172\.(1[6-9]|2[0-9]|3[0-1])\./ || $i ~ /^192\.168\./){print $i; exit}} if(NF>0) print $1}')
[[ -z "${RECOMMEND_IP:-}" ]] && RECOMMEND_IP="127.0.0.1"

echo "管理地址（推荐）: http://$RECOMMEND_IP:8090"
echo "可用 IP: ${IPS:-127.0.0.1}"
echo "admin账号: admin"
echo "admin密码: （安全策略：不显示）"
echo "提示: 如需重置密码，请在后台重置或直接修改 data.json 中 admin 账号后重启服务。"
