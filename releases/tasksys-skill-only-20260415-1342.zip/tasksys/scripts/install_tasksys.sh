#!/usr/bin/env bash
set -euo pipefail

SKILL_DIR="$(cd "$(dirname "$0")/.." && pwd)"
TEMPLATE_DIR="$SKILL_DIR/assets/task_system_template"
TARGET_DIR="${1:-$HOME/.openclaw/workspace/task_system}"
API_UNIT_PATH="/etc/systemd/system/task-system-api.service"
BOT_UNIT_DIR="$HOME/.config/systemd/user"
BOT_UNIT_PATH="$BOT_UNIT_DIR/task-system-bot.service"
BOT_ENV_PATH="$HOME/.openclaw/task-system-bot.env"

if [[ ! -d "$TEMPLATE_DIR" ]]; then
  echo "❌ 模板目录不存在: $TEMPLATE_DIR"
  exit 1
fi

mkdir -p "$TARGET_DIR/public"
cp "$TEMPLATE_DIR/server.js" "$TARGET_DIR/server.js"
cp "$TEMPLATE_DIR/bot.js" "$TARGET_DIR/bot.js"
cp "$TEMPLATE_DIR/public/index.html" "$TARGET_DIR/public/index.html"

BOOTSTRAP_ADMIN_PASS=""
NEW_DB_CREATED=0
if [[ ! -f "$TARGET_DIR/data.json" ]]; then
  NEW_DB_CREATED=1
  if [[ -n "${TASKSYS_ADMIN_PASSWORD:-}" ]]; then
    BOOTSTRAP_ADMIN_PASS="$TASKSYS_ADMIN_PASSWORD"
  else
    BOOTSTRAP_ADMIN_PASS="$(python3 - <<'PY'
import secrets, string
alphabet = string.ascii_letters + string.digits + '!@#$%^&*()-_=+'
while True:
    p = ''.join(secrets.choice(alphabet) for _ in range(20))
    if any(c.islower() for c in p) and any(c.isupper() for c in p) and any(c.isdigit() for c in p) and any(c in '!@#$%^&*()-_=+' for c in p):
        print(p)
        break
PY
)"
  fi

  ADMIN_HASH="$(python3 - <<'PY' "$BOOTSTRAP_ADMIN_PASS"
import sys, os, hashlib, binascii
plain = sys.argv[1]
salt = os.urandom(16)
iter_n = 120000
h = hashlib.pbkdf2_hmac('sha256', plain.encode('utf-8'), salt, iter_n, dklen=32)
print(f"pbkdf2${iter_n}${binascii.hexlify(salt).decode()}${binascii.hexlify(h).decode()}")
PY
)"

  cat > "$TARGET_DIR/data.json" <<JSON
{
  "seq": 1000,
  "accounts": [
    {
      "username": "admin",
      "password": "$ADMIN_HASH",
      "tgUsername": null,
      "role": "superadmin",
      "enabled": true,
      "createdAt": "2026-03-01T00:00:00",
      "createdBy": "system"
    }
  ],
  "sessions": {},
  "tasks": [],
  "remarks": [],
  "flows": [],
  "lastReportDate": null
}
JSON
fi

mkdir -p "$(dirname "$BOT_ENV_PATH")" "$BOT_UNIT_DIR"
if [[ ! -f "$BOT_ENV_PATH" ]]; then
  cat > "$BOT_ENV_PATH" <<'ENV'
# 必填：请填入 task bot token
TG_TASK_BOT_TOKEN=
# 可选：限制 bot 监听的群（逗号分隔 chat_id）
TASK_TG_GROUP_IDS=
# 可选：默认群
TASK_TG_GROUP_ID=
ENV
fi

cat > "$BOT_UNIT_PATH" <<EOF
[Unit]
Description=Task System Telegram Bot
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
EnvironmentFile=$BOT_ENV_PATH
WorkingDirectory=$TARGET_DIR
ExecStart=/usr/bin/node $TARGET_DIR/bot.js
Restart=always
RestartSec=2

[Install]
WantedBy=default.target
EOF

cat > /tmp/task-system-api.service <<EOF
[Unit]
Description=Task System API
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
WorkingDirectory=$TARGET_DIR
Environment=TASK_BIND_HOST=${TASK_BIND_HOST:-127.0.0.1}
Environment=TASK_ALLOW_PUBLIC_BIND=${TASK_ALLOW_PUBLIC_BIND:-0}
ExecStart=/usr/bin/node $TARGET_DIR/server.js
Restart=always
RestartSec=2
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ProtectHome=read-only
ReadWritePaths=$TARGET_DIR

[Install]
WantedBy=multi-user.target
EOF

echo "ℹ️ 已生成系统服务文件草案: /tmp/task-system-api.service"
if [[ "${TASK_BIND_HOST:-127.0.0.1}" == "0.0.0.0" || "${TASK_BIND_HOST:-127.0.0.1}" == "::" ]]; then
  echo "⚠️ 检测到公网绑定 TASK_BIND_HOST=${TASK_BIND_HOST:-127.0.0.1}"
  echo "⚠️ 默认会被 server.js 安全拦截；如确认公网暴露，请显式设置 TASK_ALLOW_PUBLIC_BIND=1 并配置 HTTPS 反代 + 防火墙白名单。"
fi
echo "ℹ️ 出于安全策略，本脚本不会自动执行 sudo。请人工审核后手动安装："
echo "    sudo mv /tmp/task-system-api.service $API_UNIT_PATH"
echo "    sudo systemctl daemon-reload"
echo "    sudo systemctl enable --now task-system-api.service"

systemctl --user daemon-reload
systemctl --user enable --now task-system-bot.service

IPS=$(hostname -I 2>/dev/null | xargs)
RECOMMEND_IP=$(echo "$IPS" | awk '{for(i=1;i<=NF;i++){if($i ~ /^10\./ || $i ~ /^172\.(1[6-9]|2[0-9]|3[0-1])\./ || $i ~ /^192\.168\./){print $i; exit}} if(NF>0) print $1}')
[[ -z "${RECOMMEND_IP:-}" ]] && RECOMMEND_IP="127.0.0.1"

cat <<EOF
✅ TaskSys 安装完成

管理地址（推荐）: http://$RECOMMEND_IP:8090
可用 IP: ${IPS:-127.0.0.1}

默认管理员账号:
- username: admin
EOF

if [[ "$NEW_DB_CREATED" -eq 1 ]]; then
  echo "- password: （已随机生成；仅本次显示）"
else
  echo "- password: （未变更，沿用现有配置）"
fi

cat <<EOF

⚠️ 建议仅在内网使用（HTTP 明文），若需公网请先接入 HTTPS 与反向代理。
⚠️ 请首次登录后立即修改管理员密码。
EOF

if [[ -n "$BOOTSTRAP_ADMIN_PASS" ]]; then
  echo ""
  echo "一次性初始密码（请立即保存并尽快改密）："
  echo "$BOOTSTRAP_ADMIN_PASS"
fi
